import express from 'express';
import nodemailer from 'nodemailer';
import crypto from 'crypto'; // To generate reset tokens
import bcrypt from 'bcrypt';
import bodyParser from 'body-parser';
import cors from 'cors';
import sqlite3 from 'sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

// Setup for __dirname and __filename in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize express and database
const app = express();
const PORT = 8080;
const db = new sqlite3.Database('MYDatabase2.db');

// Middlewares
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Create users table if it doesn't exist
db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    security_question TEXT NOT NULL,
    security_answer TEXT NOT NULL
)`, (err) => {
    if (err) {
        console.error("Error creating users table:", err.message);
    } else {
        console.log("Users table created or already exists");
    }
});

// Create SolarPanels table if it doesn't exist
db.run(`CREATE TABLE IF NOT EXISTS SolarPanels (
    panelId INTEGER PRIMARY KEY AUTOINCREMENT,
    panelName TEXT NOT NULL,
    energyGenerated DECIMAL(10, 2) NOT NULL,
    tiltAngle DECIMAL(5, 2) NOT NULL,
    status TEXT CHECK(status IN ('active', 'inactive')),
    updatedTime TEXT
)`, (err) => {
    if (err) {
        console.error("Error creating SolarPanels table:", err.message);
    } else {
        console.log("SolarPanels table created or already exists");
    }
});

// Function to initialize the specified solar panel data if not present
function initializePanels() {
    const panels = [
        { panelName: "Panel A", energyGenerated: 0, tiltAngle: 30, status: "active", updatedTime: new Date().toISOString() },
        { panelName: "Panel B", energyGenerated: 0, tiltAngle: 45, status: "active", updatedTime: new Date().toISOString() },
        { panelName: "Panel C", energyGenerated: 0, tiltAngle: 25, status: "inactive", updatedTime: new Date().toISOString() }
    ];

    panels.forEach(panel => {
        // Check if the panel already exists before inserting
        db.get('SELECT * FROM SolarPanels WHERE panelName = ?', [panel.panelName], (err, row) => {
            if (err) {
                console.error(err);
            } else if (!row) {
                // Insert only if the panel doesn't exist
                db.run('INSERT INTO SolarPanels (panelName, energyGenerated, tiltAngle, status, updatedTime) VALUES (?, ?, ?, ?, ?)',
                [panel.panelName, panel.energyGenerated, panel.tiltAngle, panel.status, panel.updatedTime], function(err) {
                    if (err) {
                        console.error(err);
                    } else {
                        console.log(`Panel ${panel.panelName} added.`);
                    }
                });
            } else {
                console.log(`Panel ${panel.panelName} already exists.`);
            }
        });
    });
}

// Initialize specified panels at server start
initializePanels();

// Function to generate random energy values and tilt angles
function generateRandomData() {
    const panels = ["Panel A", "Panel B", "Panel C"]; // Specify the panels to update

    panels.forEach(panelName => {
        // Generate random values
        const newEnergy = (Math.random() * 100).toFixed(2); // Random energy between 0 and 100
        const newTiltAngle = (Math.random() * 90).toFixed(2); // Random tilt angle between 0° and 90°
        const newUpdatedTime = new Date().toISOString();

        // Update the database with new energy and tilt angle for the specified panel
        db.run('UPDATE SolarPanels SET energyGenerated = ?, tiltAngle = ?, updatedTime = ? WHERE panelName = ?',
        [newEnergy, newTiltAngle, newUpdatedTime, panelName], function(err) {
            if (err) {
                console.error(`Error updating panel ${panelName}:`, err);
            } else {
                console.log(`Updated ${panelName} with energy ${newEnergy} kWh and tilt angle ${newTiltAngle}° at ${newUpdatedTime}`);
            }
        });
    });
}

// Update random data every 30 seconds for energy generation and update time
setInterval(generateRandomData, 30 * 1000); // 30 seconds in milliseconds

// Sign-up endpoint
app.post('/signup', (req, res) => {
    const { username, email, password, question, answer } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);
    
    db.run('INSERT INTO users (username, email, password, security_question, security_answer) VALUES (?, ?, ?, ?, ?)', 
    [username, email, hashedPassword, question, answer], function (err) {
        if (err) {
            res.status(400).json({ message: 'Username or email already exists' });
        } else {
            res.status(200).json({ message: 'User signed up successfully' });
        }
    });
});

// Login endpoint
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get('SELECT password FROM users WHERE username = ?', [username], (err, row) => {
        if (err || !row || !bcrypt.compareSync(password, row.password)) {
            res.status(400).json({ message: 'Invalid username or password' });
        } else {
            res.status(200).json({ message: 'Login successful', username: username });
        }
    });
});

// Forgot password endpoint using security question
app.post('/forgot-password', (req, res) => {
    const { username, question, answer, newPassword } = req.body;

    // Find the user by username and match the security answer
    db.get('SELECT * FROM users WHERE username = ? AND security_question = ? AND security_answer = ?', [username, question, answer], (err, user) => {
        if (err || !user) {
            res.status(400).json({ message: 'Invalid username, security question, or security answer' });
        } else {
            // Hash the new password
            const hashedPassword = bcrypt.hashSync(newPassword, 10);

            // Update the user's password in the database
            db.run('UPDATE users SET password = ? WHERE username = ?', [hashedPassword, username], function(err) {
                if (err) {
                    console.error('Error updating password:', err.message);
                    res.status(500).json({ message: 'Error updating password' });
                } else {
                    res.status(200).json({ message: 'Password has been reset successfully' });
                }
            });
        }
    });
});

// Endpoint to get solar panels information
app.get('/panels', (req, res) => {
    db.all('SELECT * FROM SolarPanels', [], (err, rows) => {
        if (err) {
            res.status(500).json({ message: 'Database error' });
        } else {
            res.status(200).json(rows);
        }
    });
});

// Serve frontend
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html')); // Serve the login page first
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
